package com.example.vechi_co.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class send_complaint extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_send_complaint);
    }
}