package com.example.vechi_co;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class custom_view_bookings extends BaseAdapter {
    String[] id, ser,dat,pay,lat,lon,sts;
    private Context context;
    public custom_view_bookings(Context context,String[] id,String[] ser,String[] dat,String[] pay,String[] lat,String[] lon,String[] sts) {
        this.context = context;
        this.id = id;
        this.ser = ser;
        this.dat = dat;
        this.pay = pay;
        this.lat=lat;
        this.lon=lon;
        this.sts=sts;

    }
    @Override
    public int getCount() {
        return id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_bookings,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView tv1=(TextView)gridView.findViewById(R.id.textView14);
        TextView tv2=(TextView)gridView.findViewById(R.id.textView15);
        TextView tv3=(TextView)gridView.findViewById(R.id.textView19);
        TextView tv4=(TextView)gridView.findViewById(R.id.textView28);
        Button bt1=(Button) gridView.findViewById(R.id.button8);
        Button bt2=(Button) gridView.findViewById(R.id.button9);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri navigationIntentUri = Uri.parse("google.navigation:q=" + lat[i] +"," + lon);//creating intent with latlng
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, navigationIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                mapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(mapIntent);
            }
        });
//        ImageView im=(ImageView) gridView.findViewById(R.id.imageView10);



        tv1.setText(ser[i]);
        tv2.setText(dat[i]);
        tv3.setText(pay[i]);
        tv4.setText(sts[i]);
//        tv4.setText(lat[i]);
//        tv5.setText(lon[i]);


//        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
//        String ip=sh.getString("ip","");
//
//        String url="http://" + ip + ":5000/static/game/"+gamecode[i]+".jpg";


//        Picasso.with(context).load(url).transform(new CircleTransform()). into(im);

        return gridView;
    }
}

