package com.example.vechi_co;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_service_provider extends BaseAdapter {
    String[] id,nme,con,plc,eml,lat,lon;
    private Context context;
    public custom_view_service_provider(Context context, String[] id, String[] nme, String[] con,String[] plc,String[] eml,String[] lat,String[] lon){
        this.context = context;
        this.id = id;
        this.nme = nme;
        this.con=con;
        this.plc=plc;
        this.eml=eml;
        this.lat=lat;
        this.lon=lon;

    }
    @Override
    public int getCount() {
        return nme.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.activity_custom_view_service_provider,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView tv1=(TextView)gridView.findViewById(R.id.textView3);
        TextView tv2=(TextView)gridView.findViewById(R.id.textView5);
        TextView tv3=(TextView)gridView.findViewById(R.id.textView7);
        TextView tv4=(TextView)gridView.findViewById(R.id.textView9);
        Button bt=(Button) gridView.findViewById(R.id.button6);
        Button bt1=(Button) gridView.findViewById(R.id.button10);
        Button bt2=(Button) gridView.findViewById(R.id.button12);
        bt2.setTag(i);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = (int)view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("id",id[pos]);
                ed.commit();
                Intent i = new Intent(context,send_complaint.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });
        bt1.setTag(i);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = (int)view.getTag();
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("id",id[pos]);
                ed.commit();
                Intent i = new Intent(context,notes.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
//                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
//                String url = sh.getString("url", "") + "/book_service";
//                RequestQueue requestQueue = Volley.newRequestQueue(context);
//                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
//                        new Response.Listener<String>() {
//                            @Override
//                            public void onResponse(String s) {
//                                try {
//                                    JSONObject jsonObject = new JSONObject(s);
//                                    if (jsonObject.getString("status").equalsIgnoreCase("ok")){
//                                        String lid=jsonObject.getString("lid");
//                                        SharedPreferences.Editor ed=sh.edit();
//                                        ed.putString("lid", lid);
//                                        ed.commit();
//                                        Intent i=new Intent(context, Home.class);
//                                        context.startActivity(i);
//                                    }
//
//                                }
//                                catch (Exception e){
//                                    Toast.makeText(context, "error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
//                                }
//
//                            }
//                        },
//                        new Response.ErrorListener() {
//                            @Override
//                            public void onErrorResponse(VolleyError volleyError) {
//
//                            }
//                        }){
//                    @Override
//                    protected Map<String, String> getParams() {
//                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
//                        Map<String, String> params = new HashMap<String, String>();
//                        params.put("lid", sh.getString("lid", ""));
//                        params.put("pro", id[pos]);
//                        return params;
//                    }
//                };
//
//                int MY_SOCKET_TIMEOUT_MS=100000;
//
//                postRequest.setRetryPolicy(new DefaultRetryPolicy(
//                        MY_SOCKET_TIMEOUT_MS,
//                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
//                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
//                requestQueue.add(postRequest);
            }
        });
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri navigationIntentUri = Uri.parse("google.navigation:q=" + lat[i] +"," + lon);//creating intent with latlng
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, navigationIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                mapIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(mapIntent);
            }
        });
//        ImageView im=(ImageView) gridView.findViewById(R.id.imageView10);

        tv1.setTextColor(Color.BLACK);


        tv1.setText(nme[i]);
        tv2.setText(con[i]);
        tv3.setText(plc[i]);
        tv4.setText(eml[i]);


//        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
//        String ip=sh.getString("ip","");
//
//        String url="http://" + ip + ":5000/static/game/"+gamecode[i]+".jpg";


//        Picasso.with(context).load(url).transform(new CircleTransform()). into(im);

        return gridView;
    }
}