package com.example.vechi_co.ui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class view_serviceprovider extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_view_serviceprovider);
    }
}