package com.example.vechi_co;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class custom_own_service extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_own_service);
    }
}